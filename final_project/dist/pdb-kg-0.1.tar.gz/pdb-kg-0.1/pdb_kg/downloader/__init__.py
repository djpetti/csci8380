"""
Implements a tool for downloading PDB entities.
"""
