"""
Root package for PDB knowledge graph.
"""
